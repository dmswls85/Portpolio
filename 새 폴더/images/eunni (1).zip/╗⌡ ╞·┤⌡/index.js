
$(document).ready(function(){
    $("nav").hide()
    $("input img").click(function(){
      $("nav").slideToggle(800)
    })
  })
